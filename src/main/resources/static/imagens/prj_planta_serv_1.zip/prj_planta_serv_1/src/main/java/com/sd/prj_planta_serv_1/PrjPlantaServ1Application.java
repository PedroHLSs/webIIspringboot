package com.sd.prj_planta_serv_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjPlantaServ1Application {

	public static void main(String[] args) {
		SpringApplication.run(PrjPlantaServ1Application.class, args);
	}

}
